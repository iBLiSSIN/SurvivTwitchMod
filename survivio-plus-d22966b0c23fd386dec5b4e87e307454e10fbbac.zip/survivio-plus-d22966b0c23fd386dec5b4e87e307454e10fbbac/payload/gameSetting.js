window.gameSetting = {};

window.gameSetting.UserSetting = {
	
};