![alt text](https://puu.sh/B03Pw/9a547140e8.PNG "Survivio Banner")

# Welcome to Surviv+! 😃

This is a Surviv.io cheat loaded as a Chrome extension. It was originally developed by [reuke](https://github.com/reuke), but since he has been away, I've decided to take ownership of the development of the code.


### 💪 Features

* Displays enemy lines
* Aimbot with customizable prediction and speed settings
* Custom zooming control with scroll wheel
* FPS Counter
* Autoloot
* Transparent buildings, ceilings, obstacles, and trees
* Lasersight (shot range)
* Frag grenade timer
* Custom key bindings
* **New!** Custom cursors
* **New!** Now supports in-game radio!

## 🔨 Installation

1. Download [this repo as a ZIP file](https://github.com/Kalaborative/survivio-cheat/archive/master.zip). 
2. Extract the ZIP file you just downloaded. 
3. Go to `chrome://extensions` in your browser. *Make sure you have Developer Mode activated.*
4. Click "Load Unpacked" and select the folder that you extracted (called `survivio-cheat-master`)
5. Open [surviv.io](http://surviv.io).

## 🤔 FAQ
> **What do I do if the cheat stops working?**

This usually means the game's code was patched (meaning they updated it where variables and functionality has changed). If this happens, the most you can do is create an issue. Give it some time and the cheat will work again.

> **This feature isn't working for me! WTF?**

Relax. Open the console (Hit F12), and copy what the error is, and just [create an issue](https://github.com/Kalaborative/survivio-cheat/issues).

> **Does this hack give you infinite health?**

No.

> **What about slowdown of bullets?**

Nope.

> **Okay, what about auto trigger?**

It's being looked into. Could be a possibility.

> **What is "bump fire"?**

This is a feature for specific non-automatic guns (guns that you cannot hold down the left-click to shoot). By holding down left-click for these guns, they fire at the fastest rate acting like an automatic. (Think of it like an autoclicker.)

> **Why isn't this on the Chrome Web Store?**

This was on the store before, but it got taken down (not sure why). I could try uploading it myself, but this will be the safest route for now.

> **Are pull requests allowed?**

Your contributions are always welcome. If you see something that should be improved or a feature added, feel free to fork this repo and create a PR. 
